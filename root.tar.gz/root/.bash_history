history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer
hostname
cat /etc/hostname
ping 8.8.8.8
apt update
apt-get update
echo "nameserver 8.8.8.8" 
echo "nameserver 8.8.8.8" | tee /etc/resolv.conf
apt update
cat /etc/resolv.conf
ping google.com
nano /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
apt upgrade -y
apt full-upgrade  -y
cat /etc/os-release
apt install openssh-server -y
poweroff
clear
vi /etc/ssh/sshd_config
cat /etc/ssh/sshd_config | less
systemctl restart ssh
systemctl restart ssh
systemctl status ssh
ls /oot
ls /root
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz  -C /root
ls 
ls Material_Adicional_TPVMCA
apt-get update
apt install apache2
systemctl status apache
systemctl status apache2
mkdir -p /root/.ssh
cp /root/Material_Adicional_TPVMCA/clave_publica.pub  /root/.ssh/authorized_key
ls .ssh
ls /root/.ssh/authorized_key
ls /root/.ssh/authorized_key [B
ls /root/.ssh/authorized_key
chmod 700 /root/.ssh/[B
chmod 600 /root/.ssh/authorized_key 
chmod 600 /root/.ssh/authorized_keys 
ls /root
ls -l /root
ls -a /root
ls -a /root/.ssh
mv /root/.ssh/authorized_key /root/.ssh/authorized_keys
apt install php
apt install libapache2-mod-php
php -v
apt install mariadb-server
systemclt status mariadb
systemctl status mariadb
mariadb < /root/Material_Adicional_TPVMCA
mariadb < /root/Material_Adicional_TPVMCA/db.sql
mariadb
shotdown
shutdown -h now
vi /etc/network/interfaces
vi /etc/network/interfaces
ip a
ip address
vi /etc/network/interfaces
reboot
ip a
ping 192.168.0.119
clear
poweroff
clear
mariadb
mariadb
tail -20 /var/log/apache2/error.log 
apt install php8.2-mysql
systemctl retart apache2
systemctl restart apache2
poweroff
mkdir -p /opt/scripts
vi /opt/scripts/backup_full.sh
chmod 755 /opt/scripts/backup_full.sh 
cd /opt/scripts/
-help
backup_full.sh -help
cd backup_full.sh
/opt/scripts/backup_full.sh -help
cat backup_full.sh 
cd ..
cd ..
/opt/scripts/backup_full.sh -help
vi /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
cat backup_full.sh 
cat /opt/scripts/backup_full.sh 
vi /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /var/log /backup_dir/
vi /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log /backup_dir/
ls /backup_dir/
vi /opt/scripts/backup_full.sh
ls /backup_dir/
vi /opt/scripts/backup_full.sh
ls /backup_dir/
rm /backup_dir/\{%ORIGEN\}_bkp_20260613.tar.gz 
ls /backup_dir/
/opt/scripts/backup_full.sh /var/log /backup_dir/
ls /backup_dir/
/opt/scripts/backup_full.sh 
/opt/scripts/backup_full.sh  /directorio/falso /backup_dir
systemctl status crom
systemctl status cron
crontab -e
crontab -l
crontab -e
crontab 'l

q
q
crontab -l
cat /proc/partitions > /opt/particion
cat /opt/particion
vi /etc/apache2/sites-available/000-default.conf 
vi /etc/apache2/apache2.conf 
head -20 /www_dir/index.php 
vi /opt/scripts/backup_full.sh
crontab -e
cat /opt/particion 
poweroff
clear
cat /etc/apt/sources.list
cat /etc/os-release 
clear
ls
ls
ls
ls
ls /www_dir/
cat /etc/apache2/apache2.conf 
cat /etc/apache2/apache2.conf | less
cat /etc/ssh/ssh_config
cat /etc/ssh/ssh_config | less
cat /etc/ssh/sshd_config | less
qq
vi /etc/ssh/sshd_config 
cat /etc/apache2/apache2.conf | less
vi /etc/apache2/sites-available/000-default.conf 
ls /etc/apache2/sites-available/
cat /etc/apache2/apache2.conf | less
ls
ls Material_Adicional_TPVMCA
cat db.sql
cat /root/Material_Adicional_TPVMCA/db.sql 
vi  /root/Material_Adicional_TPVMCA/db.sql 
mariadb SHOW DATABASES;
mariadb SHOW DATABASES;
mariadb SHOW DATABASES; | grep "ingenieria"
mariadb SHOW DATABASES; | grep "ing"
mariadb SHOW DATABASES; | grep -e ingen
mariadb SHOW DATABASES; | less
mariadb SHOW DATABASES; | less
mariadb
vi /etc/network/interfaces
ip a
vi /etc/fstab 
crontab -e
reboot
cat etc/hostname
cat /etc/hostname
vi /etc/host
:wq
vi /etc/hostname
reboot
hostnamectl set-hostname TPserver
cat /etc/hostname
reboot
clear
cat /etc/apt/network/ | less
cat /etc/apt/sources.list | less
cat /etc/apt/sources.list 
apt-get update
clear
poweroff
clear
crontab -e
ls -l /www_dir/
ls -l /
ls -l / | grep -e back
clear
poweroff
