#!/bin/bash
# Script de backup completo
# Uso: ./backuo_full.sh <origen> <destino>

#Opcion de ayuda
if [ "$1" == "-help" ]; then
	echo "Uso: $0 <origen> <destino>"
	echo "Ejemplo: $0 /var/log /backup_dir"
	exit 0
fi

#Variables de origen y destino
ORIGEN=$1
DESTINO=$2

#Validar cantidad de argumentos
if [ $# -ne 2 ]; then
	echo "Error: debe proporcionar origen y destino"
	echo "Ejecute $0 -help para mas informacion"
	exit 1
fi

if [ ! -d "$ORIGEN" ]; then
	echo "Error: el directorio de origen $ORIGEN no existe"
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: el directorio de destino $DESTINO no existe"
	exit 1
fi

#Generar fecha y nombre del bkp
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)

#Realizar el bkp
echo  "Iniciando backup de $ORIGEN hacia $DESTINO"
tar -czf "$DESTINO/{$NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"
echo "Backup finalizado: ${NOMBRE}_bkp_${FECHA}.tar.gz"

exit 0 	
